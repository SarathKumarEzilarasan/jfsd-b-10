package demo;

public interface WishService {
    String getWish();
}
