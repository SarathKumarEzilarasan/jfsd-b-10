package demo;

import org.springframework.stereotype.Component;

@Component("myFootballCoach")
public class FootballCoach implements Coach{
    public String getDailyWorkOut() {
        return "Spend 30 mins kicking practice";
    }

    @Override
    public String getDailyWish() {
        return "";
    }
}
