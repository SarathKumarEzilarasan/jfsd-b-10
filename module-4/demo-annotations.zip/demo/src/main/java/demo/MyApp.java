package demo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.ArrayList;

public class MyApp {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(SportsConfig.class);

        CricketCoach coach = context.getBean("cricketCoach", CricketCoach.class);
        System.out.println(coach);
        ArrayList arrayList = context.getBean("arrayList", ArrayList.class);
        System.out.println(arrayList);
        context.close();


    }
}
