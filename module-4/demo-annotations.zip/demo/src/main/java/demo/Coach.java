package demo;

public interface Coach {
    public String getDailyWorkOut();
    String getDailyWish();
}
