package com.example.springboot_demo.controller;

import com.example.springboot_demo.bean.Student;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("students")
public class StudentController {
    static List<Student> students;

    static {
        students = Arrays.asList(
                new Student(1, "john", "doe"),
                new Student(2, "jane", "doe"),
                new Student(3, "peter", "doe")
        );
    }

    @GetMapping("/student")
    public ResponseEntity<Student> getStudent() {
        Student student = new Student(1, "john", "doe");
        return new ResponseEntity<>(student, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Student>> getStudents() {
        return new ResponseEntity<>(students, HttpStatus.OK); // select * from students;
    }

    // select * from students where id = ?;
    @GetMapping("{id}")
    public ResponseEntity<Student> getStudentPathVariable(@PathVariable("id") int studentId) {
        return new ResponseEntity<>(students.get(studentId), HttpStatus.OK);
    }

    // select * from students where id = ?;
    @GetMapping("query")
    public ResponseEntity<Student> getStudentRequestParam(@RequestParam("id") int studentId) {
        return new ResponseEntity<>(students.get(studentId), HttpStatus.OK);
    }



}
