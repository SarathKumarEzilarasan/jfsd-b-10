package com.example.todo_app.controller;

import com.example.todo_app.dto.TodoDto;
import com.example.todo_app.service.ToDoService;
import jakarta.websocket.server.PathParam;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/todos")
public class TodoController {
    private ToDoService toDoService;

    public TodoController(ToDoService toDoService) {
        this.toDoService = toDoService;
    }

    @PostMapping
    public ResponseEntity<TodoDto> addTodo(@RequestBody TodoDto todoDto) {
        TodoDto savedDto = toDoService.addToDo(todoDto);
        return new ResponseEntity<>(savedDto, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<TodoDto> getTodo(@PathParam("id") Long todoId) {
        TodoDto savedDto = toDoService.getToDo(todoId);
        return new ResponseEntity<>(savedDto, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<TodoDto>> getAllTodos() {
        List<TodoDto> savedDto = toDoService.getAllTodos();
        return new ResponseEntity<>(savedDto, HttpStatus.OK);
    }

    @PutMapping("{id}")
    public ResponseEntity<TodoDto> updateTodo(@PathParam("id") Long todoId, @RequestBody TodoDto todoDto) {
        TodoDto savedDto = toDoService.updateTodo(todoDto, todoId);
        return new ResponseEntity<>(savedDto, HttpStatus.OK);
    }

    @PatchMapping("{id}/complete")
    public ResponseEntity<TodoDto> completeTodo(@PathParam("id") Long todoId) {
        TodoDto savedDto = toDoService.completeTodo(todoId);
        return new ResponseEntity<>(savedDto, HttpStatus.OK);
    }

    @PatchMapping("{id}/incomplete")
    public ResponseEntity<TodoDto> incompleteTodo(@PathParam("id") Long todoId) {
        TodoDto savedDto = toDoService.incompleteTodo(todoId);
        return new ResponseEntity<>(savedDto, HttpStatus.OK);
    }

}
