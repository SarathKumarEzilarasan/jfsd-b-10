package com.example.todo_app.service.impl;

import com.example.todo_app.dto.TodoDto;
import com.example.todo_app.entity.Todo;
import com.example.todo_app.exception.ResourceNotFoundException;
import com.example.todo_app.repository.ToDoRepository;
import com.example.todo_app.service.ToDoService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ToDoServiceImpl implements ToDoService {
    private ToDoRepository toDoRepository;
    private ModelMapper modelMapper;

    public ToDoServiceImpl(ToDoRepository toDoRepository, ModelMapper modelMapper) {
        this.toDoRepository = toDoRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public TodoDto addToDo(TodoDto todoDto) {

        Todo todo = modelMapper.map(todoDto, Todo.class);
        Todo savedToDo = toDoRepository.save(todo);

        return modelMapper.map(savedToDo, TodoDto.class);
    }

    @Override
    public TodoDto getToDo(Long id) {
        Todo todo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id:" + id));

        return modelMapper.map(todo, TodoDto.class);
    }

    @Override
    public List<TodoDto> getAllTodos() {
        return toDoRepository.findAll().stream().map(todo -> modelMapper.map(todo, TodoDto.class)).toList();
    }

    @Override
    public TodoDto updateTodo(TodoDto todoDto, Long id) {
        Todo todo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id:" + id));
        todo.setTitle(todoDto.getTitle());
        todo.setDescription(todoDto.getDescription());
        todo.setCompleted(todoDto.isCompleted());

        toDoRepository.save(todo);

        return modelMapper.map(todo, TodoDto.class);
    }

    @Override
    public void deleteTodo(Long id) {
        Todo todo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id:" + id));
        toDoRepository.deleteById(id);
    }

    @Override
    public TodoDto completeTodo(Long id) {
        Todo todo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id:" + id));

        todo.setCompleted(true);
        toDoRepository.save(todo);
        return modelMapper.map(todo, TodoDto.class);
    }

    @Override
    public TodoDto incompleteTodo(Long id) {
        Todo todo = toDoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Todo not found with id:" + id));

        todo.setCompleted(false);
        toDoRepository.save(todo);
        return modelMapper.map(todo, TodoDto.class);
    }
}
