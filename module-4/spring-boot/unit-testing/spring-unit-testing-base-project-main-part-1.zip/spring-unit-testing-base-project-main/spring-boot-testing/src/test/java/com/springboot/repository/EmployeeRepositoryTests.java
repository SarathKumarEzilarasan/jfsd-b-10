package com.springboot.repository;

import com.springboot.model.Employee;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;


@DataJpaTest
public class EmployeeRepositoryTests {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Test
    public void givenEmployee_whenSave_thenReturnSavedEmployee() {
        // given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");
        // when
        Employee savedEmployee = employeeRepository.save(employee);
        // then
        assertThat(savedEmployee).isNotNull();
        assertThat(savedEmployee.getId()).isGreaterThan(0);
    }

    @Test
    public void givenEmployeesList_whenFindAll_thenReturnEmployeeList() {
        // given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");
        Employee employee1 = new Employee();
        employee1.setFirstName("peter");
        employee1.setLastName("doe");
        employee1.setEmail("peter@gmail.com");

        employeeRepository.save(employee);
        employeeRepository.save(employee1);

        // when
        List<Employee> employeeList = employeeRepository.findAll();
        // then
        assertThat(employeeList).isNotNull();
        assertThat(employeeList.size()).isEqualTo(2);
    }

    @Test
    public void givenEmployeeObject_whenFindById_thenReturnEmployee() {
        // given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");
        employeeRepository.save(employee);

        // when
        Employee employee1 = employeeRepository.findById(employee.getId()).get();
        // then
        assertThat(employee1).isNotNull();
    }

    // findByEmail ?????????

    @DisplayName("Test case to validate update method in employee repository")
    @Test
    public void givenEmployee_whenUpdateEmployee_thenReturnUpdatedEmployee() {
        // given
        Employee employee = new Employee();
        employee.setFirstName("john");
        employee.setLastName("doe");
        employee.setEmail("john@gmail.com");
        employeeRepository.save(employee);
        // when
        Employee employee1 = employeeRepository.findById(employee.getId()).get();
        employee1.setFirstName("peter");
        Employee updatedEmployee = employeeRepository.save(employee1);
        // then
        assertThat(updatedEmployee.getFirstName()).isEqualTo("peter");
    }


}

// TDD