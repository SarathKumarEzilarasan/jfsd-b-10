package com.example.spring_data_demo.controller;

import com.example.spring_data_demo.entity.Student;
import com.example.spring_data_demo.repository.CourseRepository;
import com.example.spring_data_demo.service.StudentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {
    private StudentService studentService;
    private CourseRepository courseRepository;

    public StudentController(StudentService studentService, CourseRepository courseRepository) {
        this.studentService = studentService;
        this.courseRepository = courseRepository;
    }

    @GetMapping
    public List<Student> getAllStudents(){
        return studentService.getAllStudents();
    }

    @GetMapping("{id}")
    public Student getStudentById(@PathVariable Long id){
        return studentService.getStudentsById(id);
    }

    @PostMapping
    public Student createStudent(@RequestBody Student student){
//        courseRepository.saveAll(student.getCourses());
        return studentService.saveStudent(student);
    }



}
