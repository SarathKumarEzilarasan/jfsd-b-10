package com.example.spring_data_demo.service;

import com.example.spring_data_demo.entity.User;
import com.example.spring_data_demo.entity.UserProfile;
import com.example.spring_data_demo.repository.UserProfileRepository;
import com.example.spring_data_demo.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private UserRepository userRepository;
    private UserProfileRepository userProfileRepository;

    public UserService(UserRepository userRepository, UserProfileRepository userProfileRepository) {
        this.userRepository = userRepository;
        this.userProfileRepository = userProfileRepository;
    }

    @Transactional
    public User createUserWithProfile(String name, String bio) {
        UserProfile userProfile = new UserProfile();
        userProfile.setBio(bio);
        userProfileRepository.save(userProfile);


        User user = new User();
        user.setName(name);
        user.setUserProfile(userProfile);
        return userRepository.save(user);
    }

    public User getUserById(Long id) {
        return userRepository.findById(id).get();
    }

}
