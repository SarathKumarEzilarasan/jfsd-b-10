package com.example.demo_webflux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoWebfluxApplicationTests {

	@Test
	void contextLoads() {
	}

}
