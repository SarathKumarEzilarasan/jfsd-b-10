package com.example.demo_webflux.service.impl;

import com.example.demo_webflux.dto.EmployeeDto;
import com.example.demo_webflux.entity.Employee;
import com.example.demo_webflux.repository.EmployeeRepository;
import com.example.demo_webflux.service.EmployeeService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;
    private ModelMapper modelMapper;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository, ModelMapper modelMapper) {
        this.employeeRepository = employeeRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public Mono<EmployeeDto> saveEmployee(EmployeeDto employeeDto) {
        Employee employee = modelMapper.map(employeeDto, Employee.class);
        Mono<Employee> savedEmployee = employeeRepository.save(employee);

        return savedEmployee.map(employee1 -> modelMapper.map(employee1, EmployeeDto.class));
    }

    @Override
    public Mono<EmployeeDto> getEmployee(String employeeId) {

        return null;
    }

    @Override
    public Flux<EmployeeDto> getAllEmployee() {
        return employeeRepository.findAll()
                .map(employee -> modelMapper.map(employee, EmployeeDto.class));
    }

    @Override
    public Mono<EmployeeDto> updateEmployee(EmployeeDto employeeDto, String employeeId) {
        return null;
    }

    @Override
    public Mono<Void> deleteEmployee(String employeeId) {
        return null;
    }
}
