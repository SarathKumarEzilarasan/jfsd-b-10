package com.example.spring_data_demo.service;

import com.example.spring_data_demo.entity.Department;
import com.example.spring_data_demo.entity.Employee;
import com.example.spring_data_demo.repository.DepartmentRepository;
import com.example.spring_data_demo.repository.EmployeeRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentService {
    private DepartmentRepository departmentRepository;
    private EmployeeRepository employeeRepository;

    public DepartmentService(DepartmentRepository departmentRepository, EmployeeRepository employeeRepository) {
        this.departmentRepository = departmentRepository;
        this.employeeRepository = employeeRepository;
    }

    @Transactional
    public Department createDepartmentWithEmployees(String departmentName, List<String> employeesNames) {
        Department department = new Department();
        department.setName(departmentName);

        List<Employee> employees = employeesNames.stream().map(name -> {
            Employee employee = new Employee();
            employee.setName(name);
            employee.setDepartment(department);
            return employee;
        }).toList();

        department.setEmployees(employees);
        return departmentRepository.save(department);
    }

    public Department getDepartmentById(Long id) {
        return departmentRepository.findById(id).get();
    }

    public List<Employee> getEmployeesByDepartment(Long departmentId) {
        return employeeRepository.findByDepartmentId(departmentId);
    }
}
