package com.example.springboot_demo;

import com.example.springboot_demo.dto.UserDto;
import com.example.springboot_demo.entity.User;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import java.util.Arrays;

@SpringBootApplication
public class SpringbootDemoApplication {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();
//        TypeMap<UserDto, User> typeMap = modelMapper.createTypeMap(UserDto.class, User.class)
//                .addMapping(UserDto::getEmail, User::setFirstName);

        return new ModelMapper();
    }

    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(SpringbootDemoApplication.class, args);

//        Arrays.stream(context.getBeanDefinitionNames()).forEach(bean -> System.out.println(bean));
    }

}
