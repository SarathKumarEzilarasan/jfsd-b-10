package com.example.login_app.service.impl;

import com.example.login_app.service.UserService;

public class UserServiceImpl implements UserService {
}
