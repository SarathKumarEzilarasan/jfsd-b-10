package com.example.thymeleaf.controller;

import com.example.thymeleaf.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Arrays;
import java.util.List;

@Controller
public class HelloWorldController {

    @GetMapping("/hello")
    public String helloWorld(Model model) {
        model.addAttribute("message", "from java code");
        return "hello";
    }

    @GetMapping("/variable-expression")
    public String variableExpression(Model model) {
        User user = new User("admin", "ADMIN", "admin@gmail.com", "Male");
        model.addAttribute("user", user);
        return "variable_expression";
    }

    @GetMapping("/selection-expression")
    public String selectionExpression(Model model) {
        User user = new User("admin", "ADMIN", "admin@gmail.com", "Male");
        model.addAttribute("user", user);
        return "selection_expression";
    }

    @GetMapping("/link-expression")
    public String linkExpression(Model model) {
        model.addAttribute("id", 1);
        return "link_expression";
    }

    @GetMapping("/fragment-expression")
    public String fragmentExpression() {
        return "fragment_expression";
    }

    @GetMapping("/users")
    public String users(Model model) {
        User admin = new User("admin", "ADMIN", "admin@gmail.com", "Male");
        User john = new User("john", "USER", "john@gmail.com", "Male");
        User peter = new User("peter", "USER", "peter@gmail.com", "Male");

        List<User> users = Arrays.asList(admin, john, peter);
        model.addAttribute("users", users);
        return "users";
    }

    @GetMapping("/if-unless")
    public String ifUnless(Model model) {
        User admin = new User("admin", "ADMIN", "admin@gmail.com", "Male");
        User john = new User("john", "USER", "john@gmail.com", "Male");
        User peter = new User("peter", "USER", "peter@gmail.com", "Male");

        List<User> users = Arrays.asList(admin, john, peter);
        model.addAttribute("users", users);
        return "if_unless";
    }


    @GetMapping("/switch-case")
    public String switchCase(Model model) {
        User admin = new User("admin", "ADMIN", "admin@gmail.com", "Male");
        model.addAttribute("user", admin);
        return "switch_case";
    }


}
