package com.example.login_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.*;

@SpringBootApplication
public class LoginAppApplication {

    public static void main(String[] args) {
		SpringApplication.run(LoginAppApplication.class, args);
    }
}
