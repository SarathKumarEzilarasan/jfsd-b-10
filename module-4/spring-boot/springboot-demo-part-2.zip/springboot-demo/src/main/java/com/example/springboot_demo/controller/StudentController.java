package com.example.springboot_demo.controller;

import com.example.springboot_demo.bean.Student;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("students")
public class StudentController {
    static List<Student> students;

    static {
        students = Arrays.asList(
                new Student(1, "john", "doe"),
                new Student(2, "jane", "doe"),
                new Student(3, "peter", "doe")
        );
    }

    @GetMapping("/student")
    public ResponseEntity<Student> getStudent() {
        Student student = new Student(1, "john", "doe");
        return new ResponseEntity<>(student, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Student>> getStudents() {
        return new ResponseEntity<>(students, HttpStatus.OK); // select * from students;
    }

    // select * from students where id = ?;
    @GetMapping("{id}")
    public ResponseEntity<Student> getStudentPathVariable(@PathVariable("id") int studentId) {
        return new ResponseEntity<>(students.get(studentId), HttpStatus.OK);
    }

    // select * from students where id = ?;
    @GetMapping("query")
    public ResponseEntity<Student> getStudentRequestParam(@RequestParam("id") int studentId) {
        return new ResponseEntity<>(students.get(studentId), HttpStatus.OK);
    }

    // insert into students (cols) values ()
    @PostMapping("create")
    public ResponseEntity<Student> createStudent(@RequestBody Student student) {
        return new ResponseEntity<>(student, HttpStatus.CREATED);
    }

    // update students set col=value where ?
    @PutMapping("update/{id}")
    public ResponseEntity<Student> updateStudent(@RequestBody Student student, @PathVariable("id") int studentId) {
        Student s = students.get(studentId);
        s.setId(student.getId());
        s.setFirstName(student.getFirstName());
        s.setLastName(student.getLastName());

        return new ResponseEntity<>(student, HttpStatus.OK);
    }

    // delete from students where ?
    @DeleteMapping("delete/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable("id") int studentId) {
//        students.remove(studentId);
        return new ResponseEntity<>("deleted", HttpStatus.NO_CONTENT);
    }
}
