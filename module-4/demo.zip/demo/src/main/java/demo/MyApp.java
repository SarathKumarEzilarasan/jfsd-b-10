package demo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyApp {

    public static void main(String[] args) {
//        Tight coupling
//        CricketCoach cricketCoach = new CricketCoach();
//        System.out.println(cricketCoach.getDailyWorkOut());
//
//        FootballCoach footballCoach = new FootballCoach();
//        System.out.println(footballCoach.getDailyWorkOut());

//        Loose coupling
//        Coach coach = new CricketCoach(new HappyWishService());
//        CricketCoach coach = new CricketCoach();
//        coach.setWishService(new HappyWishService());
//        System.out.println(coach.getDailyWorkOut());
//        System.out.println(coach.getDailyWish());



        ClassPathXmlApplicationContext context =
                new ClassPathXmlApplicationContext("config.xml");

        Coach coach = context.getBean("myCricketCoach", Coach.class);

        System.out.println(coach);
        context.close();


//        ClassPathXmlApplicationContext context =
//                new ClassPathXmlApplicationContext("config.xml");
//
//        CricketCoach coach = context.getBean("myCricketCoach", CricketCoach.class);
//        System.out.println(coach.getDailyWorkOut());
//        System.out.println(coach.getDailyWish());
//        System.out.println(coach.getEmail());
//        context.close();
    }
}
