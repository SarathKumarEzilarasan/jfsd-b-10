package demo;


import java.sql.*;

public class Demo {
    public static void main(String[] args) {
        String dbConnection = "jdbc:mysql://localhost/w3schools?" +
                "user=root&password=Rsjep@1993";
        String query = "select * from customers";

        try (Connection connection = DriverManager.getConnection(dbConnection)) {

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                System.out.println(resultSet.getInt(1) + " " + resultSet.getString(2));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

// .jar ->

// maven