function myFunc(a,b){
    return a+b;
}
let result = myFunc(1,2);
// console.log(result);


let result1 = myFunc;
// console.log(result1(1,2));

const person = {
    fname: "john",
    lname: "john",
    age: 30,
    graduated : true,
    
    fullName: function(){
        return this.fname + " " + this.lname;
    }
}

// console.log(person.fname);
// console.log(person['fname']);
console.log(person.fullName());


// x = new Boolean()