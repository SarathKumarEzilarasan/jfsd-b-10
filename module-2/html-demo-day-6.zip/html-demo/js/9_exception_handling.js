try {
    let result = 100
    console.log(result);
} catch (error) {
    if(error instanceof RangeError){
        console.error(error.message);
    }else if(error instanceof TypeError){
        console.error(error.message);
    }
}finally{
    console.log("from finally");
}
