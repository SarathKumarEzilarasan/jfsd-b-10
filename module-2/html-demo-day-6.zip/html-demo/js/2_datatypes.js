let x = 5;
let y = true;
let z = 'hello world';

let a;
let b = null;

let c = ["john","peter"];

let date = new Date()

let person = {name:"john",age:30};

console.log(typeof date);