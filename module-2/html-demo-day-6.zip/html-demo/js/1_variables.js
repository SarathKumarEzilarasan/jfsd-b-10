// variables -> automatically, var ,let , const
// ES6
 // variable hoisting , re declare , no scoping
x = 5
console.log(x);
var x