// function myFunc(a,b){
//     return a+b;
// }
// let result = myFunc(1,2);

// let result = function (a,b){
//     return a+b;
// }

// let result = (a,b) => a+b;


// console.log(result(1,2));

const nums = [40,100,1,5,25,10]

nums.forEach((value,index,array) => console.log(value + " "+ index + " "+array));
console.log(nums.filter((value,index,array) => value > 18))
