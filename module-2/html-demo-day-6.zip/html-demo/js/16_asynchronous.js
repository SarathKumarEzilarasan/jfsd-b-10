// setTimeout(() => {
//     console.log("from set timeout");
// }, 2000);

// console.log("hello world");

const fs = require('fs');

//callback hell

fs.readFile('/Users/preethir/Downloads/html-demo/js/demo.txt','utf-8',(err,data) =>{
    if(err){
        console.error(err);
    }else{
        fs.readFile('/Users/preethir/Downloads/html-demo/js/demo1.txt','utf-8',(err,data1) =>{
            if(err){
                console.error(err);
            }else{
                fs.readFile('/Users/preethir/Downloads/html-demo/js/demo1.txt','utf-8',(err,data2) =>{
                    if(err){
                        console.error(err);
                    }else{
                        console.log(data);
                        console.log(data1);
                        console.log(data2);
                    }
                })    
            }
        })    
    }
})

// console.log("hello");