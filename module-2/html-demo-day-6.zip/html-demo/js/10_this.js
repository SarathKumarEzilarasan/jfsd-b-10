// const person = {
//     fname: "john",
//     lname: "john",
//     age: 30,
//     graduated : true,
    
//     fullName: function(){
//         return this.fname + " " + this.lname;
//     }
// }

// // console.log(person.fname);
// // console.log(person['fname']);
// console.log(person.fullName());

let x = this;
console.log(x);