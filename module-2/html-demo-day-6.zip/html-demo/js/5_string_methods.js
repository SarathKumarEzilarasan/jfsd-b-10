// let text = " hello world ";

// console.log(text.length);
// console.log(text.slice(-3,-1));
// console.log(text.substring(0,4));
// console.log(text.replace('l','z'));
// console.log(text.replaceAll('l','z'));
// console.log(text.toUpperCase());
// console.log(text + "java");
// console.log(text.concat("java"));
// console.log(text.trim());
// console.log(text.charAt(1));
// console.log(text.split(" "));

// console.log(text.indexOf('h'));
// console.log(text.includes("llo"));
// console.log(text.match(""));

// template literals
let name = "sarath";
let str = `My name is ${name}`;

console.log(str);