class Car{
    constructor(name,year){
        this.name = name;
        this.year = year;
    }
    language = "";
    set lang(lang){
        this.language = lang;
    }

    get _name(){
        return this.name;
    }

    age(x){
        return x - this.year;
    }
}

const car = new Car("tata",2020);

// console.log(car.name);
// console.log(car.age(2025));
// car.lang = 'english';
// console.log(car.language);
// console.log(car._name);

// inheritance

class Model extends Car{
    constructor(name,year,model){
        super(name,year);
        this.model = model;
    }

    static hello(){
        return 'hello';
    }
}

const model = new Model("tata",2020,"tigor");

// console.log(model.name);
console.log(Model.hello());