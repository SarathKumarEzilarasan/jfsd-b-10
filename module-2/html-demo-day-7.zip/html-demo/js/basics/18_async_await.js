// async function display(){
//     let myPromise = new Promise((myResolve,myReject)=>{
//         setTimeout(()=> myResolve("hello"),3000);
//     })
    
//     console.log(await myPromise);
//     console.log(100);
// }

// display()

const fs = require('fs').promises;


async function display(){
    try {
        console.log(await fs.readFile('/Users/preethir/Downloads/html-demo/js/demo.txt','utf-8'));
        console.log(await fs.readFile('/Users/preethir/Downloads/html-demo/js/demo1.txt','utf-8'));
        console.log(await fs.readFile('/Users/preethir/Downloads/html-demo/js/dem.txt','utf-8'));
    } catch (error) {
        console.error(error.message);
    }
}

display()