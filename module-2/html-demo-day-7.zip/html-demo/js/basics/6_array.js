// const fruits = ["banana","apple","orange"]

// console.log(fruits.length);

// for(let i=0;i < fruits.length ;i++){
//     // console.log(fruits[i]);
// }

// fruits[fruits.length] = "pineapple";
// fruits[10] = "pineapple";

// console.log(typeof fruits);
// console.log(Array.isArray(fruits));

const fruits = ["banana","apple","orange"]
// const fruits2 = ["banana","apple","orange"]
const fruits3 = [["banana"],["apple"],["orange"]]

// console.log(fruits.pop());
// console.log(fruits.push("pineapple"));
// console.log(fruits.shift());
// console.log(fruits.unshift("pineapple"));
// console.log(fruits.concat(fruits2));

// console.log(fruits3.flat());
// console.log(fruits.slice(2,3));

// console.log(fruits.sort());

const nums = [40,100,1,5,25,10]

// function compare(a,b){
//     return a-b;
// }

// console.log(nums.sort(compare));


function print(value,index,array){
    console.log(value + " "+ index + " "+array);
}

// nums.forEach(print);

function filter(value,index,array){
    return value > 18;
}

// console.log(nums.filter(filter))

function myFunc(value,index,array){
    return value*value; 
}

// console.log(nums.map(myFunc));

// function reduce(total,value,index,array){

// }

// console.log(fruits.indexOf("apple"));

const keys = fruits.entries()

for(let key of keys){
    // console.log(key);
}

const q1 = [1,2,3]
const q2 = [4,5,6]
const q3 = [7,8,9]


const res = [...q1,...q2,...q3];

console.log(res);