function display(arg){
    console.log(arg);
}

// let myPromise = new Promise((myResolve,myReject)=>{
//     let x = 0;
//     if(x == 0){
//         myResolve("OK");
//     }else{
//         myReject("Error");
//     }
// })

// myPromise
// .then(data => display(data))
// .catch(error => display(error))


// let myPromise = new Promise((myResolve,myReject)=>{
//     setTimeout(()=> myResolve("hello"),3000);
// })

// console.log(myPromise);

// myPromise
// .then(data => display(data))


const fs = require('fs').promises;

fs.readFile('/Users/preethir/Downloads/html-demo/js/demo.txt','utf-8')
.then(data => {
    console.log(data);
   let promise = fs.readFile('/Users/preethir/Downloads/html-demo/js/demo1.txt','utf-8');
   return promise;
})
.then(data => {
    console.log(data);
    let promise = fs.readFile('/Users/preethir/Downloads/html-demo/js/demo2.txt','utf-8');
     return promise;
})
.then(data => console.log(data))
.catch(err => display(err))