let myMap = new Map();

myMap.set('name','john')
// myMap.set('name','peter')
myMap.set('age','25')

// console.log(myMap.get('name'));
// console.log(myMap.has('age'));

// myMap.delete('age')

// console.log(myMap.size);

function print(value,index){
    console.log(value + " "+ index);
}

myMap.forEach(print)

myMap.keys()
myMap.values()
myMap.entries()

