function func1(){
    display("hello world");
}

function display(arg){
    console.log(arg);
}

// func1()

function myCalc(num1,num2,res){
    let sum = num1+num2;
    res(sum);
}

myCalc(2,1,(arg)=>console.log(arg))