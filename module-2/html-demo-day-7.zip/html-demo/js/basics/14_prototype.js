class Person{
    constructor(name){
        this.name = name
    }
}

Person.prototype.age = 30;

const person = new Person("john");

console.log(person.name);
console.log(person.age);