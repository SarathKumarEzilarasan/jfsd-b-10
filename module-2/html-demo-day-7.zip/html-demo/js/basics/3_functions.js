function myFunc(a,b){
    return a+b;
}
let result = myFunc(1,2);
// console.log(result);


let result1 = myFunc;
// console.log(result1(1,2));

const person = {
    fname: "john",
    lname: "john",
    age: 30,
    graduated : true,
    
    fullName: function(){
        return this.fname + " " + this.lname;
    }
}

// console.log(person.fname);
// console.log(person['fname']);
// console.log(person.fullName());


// x = new Boolean()


// const obj = JSON.parse();

// const json = JSON.stringify(obj);


// function sum(a,b){
//     console.log(a+b);
// }

// function sum(a,b,c){
//     console.log(a+b+c);
// }

// sum(1,2);
// sum(1,2,3);


function sum(...args){
    let sum = 0;
    for(let arg of args){
        sum = sum+ arg;
    }
    console.log(sum);
}

sum(1,2);
sum(1,2,3);