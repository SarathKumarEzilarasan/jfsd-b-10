let form = document.getElementById("addForm");
let itemList = document.getElementById("items");
let filter = document.getElementById("filter");


form.addEventListener('submit', addItem);

function addItem(e){
    e.preventDefault();
    let newItem = document.getElementById("item").value;
    let li = document.createElement("li");
    li.className = "list-group-item";
    let textContent = document.createTextNode(newItem);
    li.appendChild(textContent);
    let deleteBtn = document.createElement('button');
    deleteBtn.className = "btn btn-danger btn-sm delete float-right";
    let deleteBtnText = document.createTextNode("X");
    deleteBtn.appendChild(deleteBtnText)
    li.appendChild(deleteBtn);
    itemList.appendChild(li);
}

itemList.addEventListener('click',removeItem);

function removeItem(e){
    let element = e.target;
    if(element.classList.contains('delete')){
       if(confirm("Are you sure??")){
        let li = element.parentElement;
        itemList.removeChild(li);
       }
    }
}

filter.addEventListener('keyup', filterItems);

function filterItems(e){
   let text = e.target.value.toLowerCase();
   let items = itemList.getElementsByTagName("li");

   Array.from(items).forEach(item => {
       let value = item.firstChild.textContent.toLowerCase();
       if(!value.includes(text)){
         item.style.display = "none";
       }
   })
}