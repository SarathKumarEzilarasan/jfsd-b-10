import React from 'react';
import ItemList from './ItemList';
// import {FaTrash} from 'react-icons/fa';


const Content = ({items,handleCheck,deleteTask}) => {
  return (
    <main>
        {items.length ?(
            <ItemList items={items} handleCheck={handleCheck} deleteTask={deleteTask}/>
        ): (
            <p style={{marginTop: "25px"}}>List is Empty</p>
        )}
    </main>
  )
}

export default Content