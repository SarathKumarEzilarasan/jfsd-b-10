import './App.css';
import Header from './Header';
import Content from './Content';
import Footer from './Footer';
import {useEffect, useState} from 'react';
import AddItem from './AddItem';
import SearchItem from './SearchItem';


function App() {
//   const[items, setItems] = useState([
//     {id:1,checked: true, description: "Practise Java"},
//     {id:2,checked: false, description: "Practise JS"},
//     {id:3,checked: false, description: "Practise React"},
// ]);


const API_URL = "http://localhost:3500/db";
const[items,setItems] = useState(
  JSON.parse(localStorage.getItem("todo_list"))
);

const[isError,setIsError] = useState(null);
const[isLoading,setIsLoading] = useState(true);

useEffect(()=>{
  const fetchItems = async ()=>{
    try {
      const response = await fetch(API_URL);
      if(!response.ok){
        throw new Error("Data not Found");
      }
      const listItems = await response.json();
      console.log(listItems);
      setItems(listItems);
    } catch (error) {
      setIsError(error.message);
    }finally{
      setIsLoading(false);
    }
  }; 
 setTimeout(async() => {
   await fetchItems();
 }, 2000);
},[])



function handleCheck(id){
    // console.log(id);
   const listItems = items.map(item => 
        // item.id === id ? {id:item.id,checked: !item.checked, description: item.description} :item
        item.id === id ? {...item,checked: !item.checked} :item
    )
    setItems(listItems);
    localStorage.setItem("todo_list",JSON.stringify(listItems));
}

function deleteTask(id){
    // const listItems = items.map(item => item.id === id ? {}:item);
    const listItems = items.filter(item => item.id !== id)
    setItems(listItems);
    localStorage.setItem("todo_list",JSON.stringify(listItems));
}

const[newItem,setNewItem] = useState();

const handleSubmit = (e)=>{
  e.preventDefault();
  addItem(newItem);
}

const addItem = (i) =>{
  const id = items.length? items[items.length-1].id +1 : 1;
  const addNewItem = {id: id, checked:false, description:i};
  const listItems = [...items,addNewItem];
  console.log(listItems);
  setItems(listItems);
  localStorage.setItem("todo_list",JSON.stringify(listItems));
  setNewItem("");
}

const[searchItem,setSearchItem] = useState("");


  return (
    <div className="App">
     <Header title= "Demo App" />
     <AddItem newItem={newItem} handleSubmit={handleSubmit} setNewItem={setNewItem}/>
     <SearchItem searchItem={searchItem} setSearchItem={setSearchItem}/>
     <main>
      {isError && <p>{isError}</p>}
      {isLoading && <p>Loading Items Please wait</p>}
      {!isError && !isLoading && (
        <Content 
        items={
          items.filter(item => item.description.toLowerCase().includes(searchItem.toLowerCase()))
        }
        handleCheck={handleCheck} 
        deleteTask={deleteTask}/>
      )}
     </main>
     <Footer length={items.length}/>
    </div>
  );
}

export default App;
