import React from 'react';
import { useRef } from 'react';

const AddItem = ({newItem,handleSubmit,setNewItem}) => {
   
  const inputRef = useRef();

  return (
    <form className='addForm' onSubmit={handleSubmit}>
        <label htmlFor='addItem'>Add Item</label>
        <input id='addItem' 
            type="text" 
            placeholder='Add Item' 
            required 
            value={newItem} 
            onChange={e=> setNewItem(e.target.value)}
            ref={inputRef}
            >
        </input>
        <button type='submit' onClick={()=> inputRef.current.focus()}>Submit</button>
    </form>
  )
}

export default AddItem