import React from 'react';
import {useState} from 'react';
// import {FaTrash} from 'react-icons/fa';


const Content = () => {

//   if(true)
//     useState()

// const[count, setCount] = useState(99);
// const[name, setName] = useState(() => display());
// const[name, setName] = useState({age:20});
// const[name, setName] = useState("john");

    // function display(){
    //     console.log("name");
    // }
    // function incrementFunc(){
    //     // setCount(count +1);
    //     // setCount(count +1);
    //     // setCount(count +1);

    //     setCount(count => ++count);
    //     // setCount(count => ++count);
    //     // setCount(count => ++count);
    // }

    // function decrementFunc(){
    //     setCount(count => --count);
    // }

    // function randomName(){
    //     const names = ["john","peter"];
    //     const i = Math.floor(Math.random()*2);
    //     return setName(names[i]);
    // }

    // const addItem = () =>{
    //     console.log("Item Added");
    // };    
    

    // const addItem1 = (name) =>{
    //     // console.log("Item Added" + name);
    // };    

    const[items, setItems] = useState([
        {id:1,checked: true, description: "Practise Java"},
        {id:2,checked: false, description: "Practise JS"},
        {id:3,checked: false, description: "Practise React"},
    ]);

    function handleCheck(id){
        // console.log(id);
       const listItems = items.map(item => 
            // item.id === id ? {id:item.id,checked: !item.checked, description: item.description} :item
            item.id === id ? {...item,checked: !item.checked} :item
        )
        setItems(listItems);
    }

    function deleteTask(id){
        // const listItems = items.map(item => item.id === id ? {}:item);
        const listItems = items.filter(item => item.id !== id)
        setItems(listItems);
    }

  return (
    // <main>
    //     <p>Logged in by {name}</p>
    //     {/* <button onClick={addItem}>Add</button> */}
    //     {/* <button onClick={addItem1("john")}>Add</button> */}
    //     {/* <button onClick={()=> addItem1("john")}>Add</button> */}
    //     {/* <button onClick={(e)=> addItem1(e)}>Add</button> */}
    //     {/* <button onClick={decrementFunc}>-</button>
    //     <span>{count}</span>
    //     <button onClick={incrementFunc}>+</button> */}

    //     <button onClick={randomName}>Add</button>
    // </main>



    <main>
        <ul>
            {items.map(item => (
                <li className='item' key={item.id}>
                    <input type="checkbox" 
                        checked={item.checked} 
                        onChange={()=> handleCheck(item.id)}>
                    </input>
                    <label style={item.checked ? {textDecoration: 'line-through'}:null}>
                        {item.description}
                        <button onClick={()=>deleteTask(item.id)}>Delete</button>
                    </label>
                </li>
            ))}
        </ul>
    </main>



  )
}

export default Content