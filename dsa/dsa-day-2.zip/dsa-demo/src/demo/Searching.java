package demo;

import java.util.Arrays;
import java.util.List;

public class Searching {

    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(10, 2, 13, 5, 6, 7, 8);

    }

    public static int binarySearch(List<Integer> list, int low, int high, int target) {
//        List<Integer> list = Arrays.asList(1, 2, 3, 5, 6, 7, 8);
//        int target = -80;
//        System.out.println(binarySearch(list, 0, list.size() - 1, target));
        if (low > high) {
            return -1;
        }
        int mid = (low + high) / 2;
        if (list.get(mid) == target) {
            return mid;
        } else if (list.get(mid) < target) {
            return binarySearch(list, mid + 1, high, target);
        } else {
            return binarySearch(list, low, mid - 1, target);
        }
    }

    public static int factorial(int n) {
        // recursion -> function calling its own name
        if (n == 0 || n == 1) {
            return 1;
        }
        return n * factorial(n - 1);
    }

    public static void print(int x) {
        // base condition
        if (x == 0) {
            return;
        }
        System.out.println(x);
        print(x - 1);
    }

    public static void constTime() {
        int x = 9;
        if (x % 2 == 0) {
            System.out.println("even");
        } else {
            System.out.println("old");
        }
    }

    public static void linearSearch() {
        // linear search
        List<Integer> list = Arrays.asList(1);
        int x = 9;

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i) == x) {
                System.out.println("found x");
            }
        }
    }

}

// Time complexity -> o(1) > o(log n) > o(n) > o( nlog n) > o(n2)
//  - best case -> o(0)
//  - worst case -> o(n)

// Space complexity

// 1....25