package demo.sorting;

import java.util.Arrays;
import java.util.List;

public class Sorting {
    public static void main(String[] args) {
        int[] arr = {1, 11, 7, -1, 0, 29};
        // merge sort
        mergeSort(arr, 0, arr.length - 1);
        Arrays.stream(arr).forEach(i -> System.out.print(i + " "));

    }

    // bubble sort -> time = o(n2)     , space = o(1)
    // merge sort  -> time = o(nlog n) , space = o(n)
    // quick sort  -> time = o(nlog n) , space = o(1) -> o(n)

    public static void mergeSort(int[] arr, int low, int high) {
        if (low >= high) {
            return;
        }
        int mid = (low + high) / 2;
        mergeSort(arr, low, mid);  // o(log n) + o(log n) -> o(log n) * o(n) -> o( nlog n) , space = o(n)
        mergeSort(arr, mid + 1, high); // o(log n)
        merge(arr, low, mid, high); // o(n)
    }

    private static void merge(int[] arr, int low, int mid, int high) {
        int n1 = mid - low + 1;
        int n2 = high - mid;

        int[] arr1 = new int[n1]; // o(n1+n2) -> o(2n) -> o(n)
        int[] arr2 = new int[n2];

        for (int i = 0; i < n1; i++) {
            arr1[i] = arr[low + i];
        }

        for (int j = 0; j < n2; j++) {
            arr2[j] = arr[mid + 1 + j];
        }

        int i = 0, j = 0, k = low;
        while (i < n1 && j < n2) {    // o(n)
            if (arr1[i] <= arr2[j]) {
                arr[k] = arr1[i];
                i++;
            } else {
                arr[k] = arr2[j];
                j++;
            }
            k++;
        }
        while (j < n2) {             // o(n)
            arr[k] = arr2[j];
            j++;
            k++;
        }
        while (i < n1) {             // o(n)
            arr[k] = arr1[i];
            i++;
            k++;
        }
    }


    //    public static void main(String[] args) {
//        // Given 2 sorted arrays -> merge it into a single sorted array
//        int[] arr1 = {1, 3, 4, 5, 7, 9, 10, 11}; // {1,2,0,0,0,0,0,0,0}
//        //                           i                         k
//        int[] arr2 = {2, 4, 6, 8, 9, 10};
//        //                     j
//        Arrays.stream(mergeArrays(arr1, arr2)).forEach(i -> System.out.print(i + " "));
//    }
    private static int[] mergeArrays(int[] arr1, int[] arr2) {
        int n1 = arr1.length;
        int n2 = arr2.length;
        int[] mergedArray = new int[n1 + n2];
        int i = 0, j = 0, k = 0; // o(n) + o(n) + o(n) ->  o(n)

        while (i < n1 && j < n2) {    // o(n)
            if (arr1[i] <= arr2[j]) {
                mergedArray[k] = arr1[i];
                i++;
            } else {
                mergedArray[k] = arr2[j];
                j++;
            }
            k++;
        }
        while (j < n2) {             // o(n)
            mergedArray[k] = arr2[j];
            j++;
            k++;
        }
        while (i < n1) {             // o(n)
            mergedArray[k] = arr1[i];
            i++;
            k++;
        }

        return mergedArray;
    }

    public static void bubbleSort() {
        List<Integer> list = Arrays.asList(10, 2, 13, 5, 6, 7, 8);
        System.out.println(list);
        // bubble sort
        for (int i = 0; i < list.size(); i++) {         //  1 -> o(n) , 2 -> o(n) , ...... n -> o(n) * o(n) -> o(n2)
            for (int j = i + 1; j < list.size(); j++) { // o(n)
                if (list.get(i) > list.get(j)) {
                    int temp = list.get(i);
                    list.set(i, list.get(j));
                    list.set(j, temp);
                }
            }
        }
        System.out.println(list);
    }


}
