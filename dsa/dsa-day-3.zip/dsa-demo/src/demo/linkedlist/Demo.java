package demo.linkedlist;

public class Demo {
    public static void main(String[] args) {

    }
}
