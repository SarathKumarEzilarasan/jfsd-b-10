package java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class IntermediateOperations {
    public static void main(String[] args) {
        // filter , peek , map , sorted


    }

    public static void doLimit() {
        List<Integer> list = Arrays.asList(10, 4, 1, 3, 20);

        list.stream().limit(2).forEach(i -> System.out.println(i));
    }

    public static void doDistinct() {
        List<Integer> list = Arrays.asList(10, 4, 1, 3, 20, 10, 10);
        list.stream().distinct().forEach(i -> System.out.println(i));
    }

    public static void doFlatMap() {
        List<Integer> list1 = Arrays.asList(10, 4, 1, 3);
        List<Integer> list2 = Arrays.asList(20, 10, 10);

        Stream<List<Integer>> stream = Stream.of(list1, list2);
        List<Integer> list3 = stream.flatMap(list -> list.stream()).toList();
        System.out.println(list3);
    }

}
