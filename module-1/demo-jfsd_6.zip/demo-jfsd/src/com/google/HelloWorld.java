package com.google;

public class HelloWorld {

    public static void main(String[] args) {
        // mutable -> string builder
//        String s = "hello";
//        String s1 = s + " world";

        StringBuilder stringBuilder = new StringBuilder(); // [h,e,l,l,o,w,o,r,l,d]
        stringBuilder.append("hello");
        stringBuilder.append("world");
        String s = stringBuilder.toString();
    }
}
