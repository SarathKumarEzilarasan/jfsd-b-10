package com.google;

public class TestEnum {

    // constants -> enum
    public static void main(String[] args) {
        print(DAY.MON);
    }

    public static void print(DAY day) {
        if (day.equals(DAY.SUN)) {
            System.out.println("sun");
        } else if (day.equals(DAY.MON)) {
            System.out.println("mon");
        } else if (day.equals(DAY.TUE)) {
            System.out.println("tue");
        } else if (day.equals(DAY.WED)) {
            System.out.println("wed");
        } else if (day.equals(DAY.THURS)) {
            System.out.println("thurs");
        } else if (day.equals(DAY.FRI)) {
            System.out.println("fri");
        } else if (day.equals(DAY.SAT)) {
            System.out.println("sat");
        }
    }
}

enum DAY {
    SUN,
    MON,
    TUE,
    WED,
    THURS,
    FRI,
    SAT
}