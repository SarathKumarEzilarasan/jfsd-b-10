package oops;

public class Test {

    private String name;

    public Test(String name) {
        this.name = name;
    }

    public String toString() {
        return "Hello from Test Class";
    }

    public boolean equals(Object o) {
        Test t = (Test) o;
        boolean flag = name.equals(t.name);
        return flag;
    }

    public int hashCode() {
        return name.length() * 100;
    }

    // Object -> parent class of every Java classes
    public static void main(String[] args) {
        Test a = new Test("john"); // 1 GB
        Test b = new Test("john"); // 1 GB ???

        System.out.println(a.equals(b)); // ??????
    }
}


// child -> parent -> child [name]
// front end -> object -> db
