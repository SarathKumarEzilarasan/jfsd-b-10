package oops;

//2.2) Create a class Book with the following properties and methods:
//Properties: bookId, title, author, price.
//Constructor should allow initializing all values.
//Method to display book details.
//Create another class Library that:
//a. Accepts five books from the user and stores them in an array.
//b. Finds and displays the most expensive book.
//c. Calculates the total cost of all books.
public class Book {
    private long bookId;
    private String title;
    private String author;
    private double price;

    public double getPrice() {
        return price;
    }

    public Book(long bookId, String title, String author, double price) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.price = price;
    }

    public void displayBookDetails() {
        System.out.println("Book Details");
    }

    public String toString() {
        return "Book id = " + bookId + " title = " + title + " author = " + author + " price = " + price;
    }

}

class Library {



    int x = 100;


    public static void main(String[] args) {
        int x = 100;

    }

    public static Book expensiveBook(Book[] books) {
        Book expensiveBook = null;
        double expensivePrice = Double.MIN_VALUE;
        for (int i = 0; i < books.length; i++) {
            if (expensivePrice < books[i].getPrice()) {
                expensivePrice = books[i].getPrice();
                expensiveBook = books[i];
            }
        }

        return expensiveBook;
    }

    // Calculates the total cost of all books.
}
