package oops;

class Parent {
    public void add() {
        System.out.println(500 + 200);
    }
}

public class Child extends Parent {

    public void sub() {
        System.out.println(100 - 200);
    }
}
