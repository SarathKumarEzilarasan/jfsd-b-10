package oops;

public class Child1 extends Parent{
}
