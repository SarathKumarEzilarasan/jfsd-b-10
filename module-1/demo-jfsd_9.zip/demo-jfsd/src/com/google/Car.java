package com.google;

public class Car {
    public void breaks() {
        System.out.println("normal break");
    }

    public void tyres() {
        System.out.println("normal tyres");
    }
}

class Bmw extends Car {
    @Override
    public void breaks() {
        System.out.println("advanced breaking system");
    }

    public void sunRoof() {
        System.out.println("sun roof");
    }
}

class Tata extends Car {

}
