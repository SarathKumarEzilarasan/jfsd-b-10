package collection;

import java.util.Set;
import java.util.TreeSet;

public class SetTest {
    // set -> unique
    public static void main(String[] args) {
//        List list = Arrays.asList(1, 2, 1, 1, 1); // {1,2,3,4,5}

        Set<String> set = new TreeSet<>(); // Hash -> Hashing -> z*10(3) + a*10(2) + c*10(1) + k*10(0) -> 122345
        set.add("zack");
        set.add("john");
        set.add("peter");


        System.out.println(set);

    }
}

// HashSet -> i want it to be faster and i dont care about the order
// LinkedHashSet -> i care about the order
// TreeSet -> i want to sort the values
