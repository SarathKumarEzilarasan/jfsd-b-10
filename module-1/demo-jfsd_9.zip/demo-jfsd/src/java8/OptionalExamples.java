package java8;

import java.util.Optional;

public class OptionalExamples {
    public static void main(String[] args) {
        _print(Optional.empty());
    }

    public static void print(String s) {
        if (s != null) {
            System.out.println(s.length());
        }
    }

    public static void _print(Optional<String> s) {
        s.ifPresent(i -> System.out.println(i));
        System.out.println(s.orElse("nothing"));
    }
}
