package java8;

public class Test {
    static void print() {
        System.out.println("from class");
    }

    public static void main(String[] args) {
        Test.print();
//        Test test = new Test();
//        test.print();

        I.print();
//        I i = new I() {
//            @Override
//            public void add() {
//
//            }
//        };
//
//        i.print();
    }
}

// default method
interface I {
    void add();

    default void sub() {
        System.out.println("I");
    }

    static void print() {
        System.out.println("from interface");
    }
}

interface J {
    void add();

    default void sub() {
        System.out.println("J");
    }
}

class A implements I, J {
    @Override
    public void add() {

    }

    public void sub() {

    }
}

class C implements I {
    @Override
    public void add() {

    }
}
