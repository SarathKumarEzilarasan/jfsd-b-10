package java8;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class FileOperations {
    private static final String FILE_PATH = "demo.txt";

    public static void main(String[] args) {
        createFile("hello world");
        readFile();
        updateFile(" from java");
        readFile();
        deleteFile();
    }

    public static void createFile(String content) {
        try {
            Files.write(Paths.get(FILE_PATH), content.getBytes(), StandardOpenOption.CREATE);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void readFile() {
        try {
            List<String> lines = Files.readAllLines(Paths.get(FILE_PATH));
            lines.forEach(System.out::println);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void updateFile(String content) {
        try {
            Files.write(Paths.get(FILE_PATH), content.getBytes(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void deleteFile() {
        try {
            Files.delete(Paths.get(FILE_PATH));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


}
