package java8;

import java.util.Arrays;
import java.util.List;
import java.util.function.*;

public class FunctionalInterfaceTest {
    public static void main(String[] args) {
//        List<Integer> list = Arrays.asList(10, 4, 1, 3, 20);
//        List<Integer> evenList = new ArrayList<>();
//
//        for (Integer i : list) {
//            if (i % 2 == 0) {
//                evenList.add(i);
//            }
//        }
//
//        System.out.println(evenList);
//        // even -> square
//        List<Integer> squareList = new ArrayList<>();
//
//        for (Integer i : evenList) {
//            squareList.add(i * i);
//        }
//
//        System.out.println(squareList);

        List<Integer> list = Arrays.asList(10, 4, 1, 3, 20);
        List<Integer> evenList = list.stream()
                .filter(i -> i % 2 == 0) // 10,4,20
                .peek(i -> System.out.println("from filter " + i))
                .map(i -> i * i)         // 100,16,400
                .peek(i -> System.out.println("from map " + i))
                .map(i -> i / 2)         // 50,8,200
                .sorted((o1, o2) -> o2.compareTo(o1)) // 200,50,8
                .toList();

        evenList.forEach(i -> System.out.println(i));
    }

    public static void predicate() {
        // Predicate -> check an input and returns boolean
        List<Integer> list = Arrays.asList(10, 4, 1, 3, 20);

        Predicate<Integer> predicate = (i) -> i % 2 == 0;
        Predicate<Integer> predicate1 = (i) -> i > 5;

        for (Integer i : list) {
            if (predicate.and(predicate1).test(i)) {
                System.out.println(i);
            }
        }

    }

    public static void function() {
        // Function -> accepts a parameter and returns a parameter
//        Function<Integer, Boolean> function = (i) -> i % 2 == 0;
        Function<Integer, Integer> function = (i) -> i * i;
        Function<Integer, Integer> function1 = (i) -> i / 2;

        System.out.println(function.andThen(function1).apply(10));

    }

    public static void consumer() {
        // consumer -> accepts an input and returns void
        Consumer<Integer> consumer = (i) -> System.out.println(i);
        consumer.accept(10);
    }

    public static void supplier() {
        // supplier -> no input but gives you an output
        Supplier<Integer> supplier = () -> 10;
        System.out.println(supplier.get());
    }

    public static void biFunctionalInterface() {
        BiPredicate<Integer, Integer> biPredicate = (i, j) -> i > j;
        BiFunction<Integer, Integer, Boolean> biFunction = (i, j) -> i > j;
        BiConsumer<Integer, Integer> biConsumer = (i, j) -> System.out.println(i + j);

        IntPredicate intPredicate = i -> i > 2; // primitive functional interface
    }

}
