package multi;

public class VolatileData {
    private volatile int counter = 0;

    public static void main(String[] args) throws InterruptedException {
        VolatileData data = new VolatileData();
        Thread t1 = new Thread(() -> {
            int oldValue = data.counter;
            System.out.println("From thread " + Thread.currentThread().getName() + " old value " + oldValue);
            int newValue = ++data.counter;
            System.out.println("From thread " + Thread.currentThread().getName() + " new value " + newValue);
        });
        Thread t2 = new Thread(() -> {
            int oldValue = data.counter;
            System.out.println("From thread " + Thread.currentThread().getName() + " old value " + oldValue);
            int newValue = ++data.counter;
            System.out.println("From thread " + Thread.currentThread().getName() + " new value " + newValue);
        });

        t1.start();
        t2.start();
        t1.join();
        t2.join();
    }
}
