package multi;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ThreadSafeDemo {
    public static void main(String[] args) throws InterruptedException {
        // hashmap -> ConcurrentHashMap
        // ArrayList -> CopyOnWriteArrayList
        // hashset -> CopyOnWriteArraySet
        // LinkedList -> ConcurrentLinkedQueue
        // TreeMap -> ConcurrentSkipListMap


        Map<Integer, Integer> nonThreadSafeMap = new HashMap<>();
        Map<Integer, Integer> threadSafeMap = new ConcurrentHashMap<>();

        runTest(threadSafeMap);

    }

    private static void runTest(Map<Integer, Integer> map) throws InterruptedException {
        ExecutorService executorService = Executors.newFixedThreadPool(10);

        for (int i = 0; i < 10; i++) {
            final int k = i;
            executorService.submit(() -> {
                for (int j = 0; j < 1000; j++) {
                    map.put(k * 1000 + j, j);
                }
            });
        }
        executorService.shutdown();
        executorService.awaitTermination(1, TimeUnit.MINUTES);
        System.out.println(map.size());

    }
}
