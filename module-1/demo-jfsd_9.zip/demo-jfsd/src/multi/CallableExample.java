package multi;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableExample {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        ExecutorService executorService = Executors.newFixedThreadPool(2);

        Future<Integer> future = executorService.submit(() -> {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            return 0;
        });

        System.out.println("Doing other work from main");
        int result = future.get();
        System.out.println(result);
        executorService.shutdown();
    }
}

// future -> manually stop , multiple futures cannot be combined , no error handling -> completableFuture