package multi;

public class JoinDeadLock {
    public static void main(String[] args) throws InterruptedException {
//        System.out.println(Thread.currentThread().getName());
//        Thread.currentThread().setName("hello");
//        System.out.println(1/0);
        Thread mt = Thread.currentThread();

        Runnable runnable = () -> {
            try {
                mt.join();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            for (int i = 0; i < 5; i++) {
                System.out.println("from child");
//                Thread.yield();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        };

        Thread t = new Thread(runnable);
//        t.setPriority(10);
        t.start();
        t.join();
        for (int i = 0; i < 5; i++) {
            System.out.println("from main");
            Thread.sleep(100);
        }

    }
}
