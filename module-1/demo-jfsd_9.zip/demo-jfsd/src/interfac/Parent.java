package interfac;

public interface Parent {
    void add();
}

interface Parent1 {
    void add();
}

class Child implements Parent, Parent1 {
    public void add() {
        System.out.println("hello from child");
    }

    public static void main(String[] args) {
        Child child = new Child();
        child.add();
    }
}
