//package oops;
//
////public class Parent1 {
////    public void sub() {
////        System.out.println(500 + 200);
////    }
////}
