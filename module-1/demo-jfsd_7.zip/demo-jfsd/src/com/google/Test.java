package com.google;

public class Test {

    // exception handling

    // compile time error
    // run time error

    public static void main(String[] args) throws AgeNotInRangeException {
        try {
            System.out.println(1 / 0);
            System.out.println("from try");
        } catch (ArithmeticException e) {
            throw new ArithmeticException();
        } finally {
            System.out.println("from finally");
        }
    }

    public static void add() throws AgeNotInRangeException {
        try {
            printAge(10);
        } catch (AgeNotInRangeException e) {

        } finally {
            System.out.println("from finally");
        }
    }

    public static void printAge(int age) throws AgeNotInRangeException {
        if (age < 18) {
            throw new AgeNotInRangeException("Age should be above 18");
        }
    }
}

class AgeNotInRangeException extends Exception {
    public AgeNotInRangeException(String message) {
        super(message);
    }
}


// throws -> try/catch -