package collection;

import java.util.LinkedList;
import java.util.List;

public class LinkedListTest {
    public static void main(String[] args) {
        // data structure -> Create add read delete update search
        List<Integer> list = new LinkedList<>();
        list.add(10);
        list.add(11);
        list.add(12);
        list.add(12);
        list.get(1);
        System.out.println(list);
        list.remove(2);
        System.out.println(list);
        list.set(0, 20);
        System.out.println(list);
        list.contains(20);

        System.out.println(list.size());


    }
}
