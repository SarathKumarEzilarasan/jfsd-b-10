package java8;

import java.util.*;
import java.util.stream.Collectors;

public class CollectorsExamples {
    public static void main(String[] args) {

    }



    public static void doJoining() {
        List<String> list = Arrays.asList("apple", "orange", "banana");

        String result = list.stream().collect(Collectors.joining(","));

        System.out.println(result);
    }

    public static void doMap1() {
        List<String> list = Arrays.asList("apple", "orange", "banana");

        Map<String, Integer> result = list.stream()
                .collect(
                        Collectors.toMap(
                                s -> s,
                                s -> s.length()
                        )
                );

        System.out.println(result);
    }

    public static void doMap2() {
        List<String> list = Arrays.asList("apple", "orange", "banana");

        Map<Integer, String> result = list.stream()
                .collect(
                        Collectors.toMap(
                                s -> s.length(),
                                s -> s,
                                (s1, s2) -> s1 + "," + s2
                        )
                );

        System.out.println(result);
    }

    public static void doMap3() {
        List<String> list = Arrays.asList("apple", "orange", "banana", "cake");

        Map<Integer, String> result = list.stream()
                .collect(
                        Collectors.toMap(
                                s -> s.length(),
                                s -> s,
                                (s1, s2) -> s1 + "," + s2,
                                () -> new TreeMap<>()
                        )
                );

        System.out.println(result);
    }

    public static void doGroupingBy1() {
        List<String> list = Arrays.asList("apple", "orange", "banana", "cake");

        Map<Integer, List<String>> map = list.stream()
                .collect(
                        Collectors.groupingBy(s -> s.length())
                );

        System.out.println(map);
    }

    public static void doGroupingBy2() {
        List<String> list = Arrays.asList("apple", "orange", "banana", "cake", "apple");

        Map<Integer, Set<String>> map = list.stream()
                .collect(
                        Collectors.groupingBy(s -> s.length(), Collectors.toSet())
                );

        System.out.println(map);
    }

    public static void doGroupingBy3() {
        List<String> list = Arrays.asList("apple", "orange", "banana", "cake", "apple");

        Map<Integer, Set<String>> map = list.stream()
                .collect(
                        Collectors.groupingBy(s -> s.length(), () -> new TreeMap<>(), Collectors.toSet())
                );

        System.out.println(map);
    }

    public static void doPartitionBy() {
        List<String> list = Arrays.asList("apple", "orange", "banana", "cake", "apple");

        Map<Boolean, List<String>> map = list.stream()
                .collect(
                        Collectors.partitioningBy(s -> s.length() > 4)
                );

        System.out.println(map);
    }
}
