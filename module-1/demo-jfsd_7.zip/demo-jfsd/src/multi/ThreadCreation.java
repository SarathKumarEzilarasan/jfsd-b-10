package multi;

public class ThreadCreation {
    // thread -> process to which we can give a task
    public static void main(String[] args) throws InterruptedException {
//        MyThread myThread = new MyThread();
//        Thread t = new Thread(myThread);
//        t.start();
//        for (int i = 0; i < 5; i++) {
//            System.out.println("from main");
//            Thread.sleep(500);
//        }

        Runnable runnable = () -> {
            for (int i = 0; i < 5; i++) {
                System.out.println("from child");
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        };

        Thread t = new Thread(runnable);
        t.start();
        for (int i = 0; i < 5; i++) {
            System.out.println("from main");
            Thread.sleep(500);
        }
    }
}
//
//class MyThread extends Thread {
//    public void run() {
//        for (int i = 0; i < 5; i++) {
//            System.out.println("from child");
//            try {
//                Thread.sleep(500);
//            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
//            }
//        }
//    }
//}

class MyThread implements Runnable {

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println("from child");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}