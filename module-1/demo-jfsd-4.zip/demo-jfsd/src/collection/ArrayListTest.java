package collection;

import java.util.Arrays;
import java.util.List;

public class ArrayListTest {
    public static void main(String[] args) {
        // collections -> set of classes and interfaces -> List, Set , Map
        // Array -> ArrayList
        // data structure -> Create add read delete update search

//        List list = Arrays.asList(1, 2, 3, 4, 5); 100 -> dynamic array
        // Generics
        List<Integer> list = Arrays.asList(1, 2); // array[10] -> 75% -> array[20] -> 75% -> array[40] .....

        list.add(10);
        list.add(20);



        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i) / 10);
        }


    }
}

// copy data from original arr to temp arr
// increase size of original arr
// copy data from temp arr to original arr