package collection;

import java.util.Stack;

public class StackTest {
    public static void main(String[] args) {
        // Stack -> Last In First Out

        Stack<Integer> stack = new Stack<>();
        stack.add(100);
        stack.add(10);
        stack.add(1);


        System.out.println(stack.pop());
        System.out.println(stack);
    }
}
// google.com -> queue images -> stack images
