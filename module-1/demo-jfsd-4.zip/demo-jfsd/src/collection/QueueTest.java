package collection;

import java.util.LinkedList;
import java.util.Queue;

public class QueueTest {
    public static void main(String[] args) {
        // Queue -> First In First Out

        Queue<Integer> queue = new LinkedList<>();
        queue.add(100);
        queue.add(10);
        queue.add(1);


        System.out.println(queue.poll());
        System.out.println(queue);
    }
}
