package oops;

public class GrandChild extends Child{
}
