package oops;

import java.util.Scanner;

//2.1) Create a class Student with the following properties and methods:
//Properties: studentId, name, marks (out of 100).
//Default marks should be 0.
//Constructor should allow initializing studentId and name.
//Method to set marks for the student.
//Method to display student details.


public class Student {
    private long studentId;
    private String name;
    private int marks;

    public Student(long studentId, String name) {
        this.studentId = studentId;
        this.name = name;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public void display() {
        System.out.println("Student details: student id = " + studentId + " name = " + name + " marks= " + marks);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter the student id");
        long studentId = Long.parseLong(scanner.nextLine());
        System.out.println("Please enter the student name");
        String name = scanner.nextLine();
        Student student = new Student(studentId, name);
        student.setMarks(85);
        student.display();
    }
}
