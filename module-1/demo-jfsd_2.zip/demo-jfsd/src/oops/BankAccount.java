package oops;

//2.3) Create a class BankAccount with the following properties and methods:
//Properties: accountNumber, holderName, balance.
//Constructor should initialize accountNumber, holderName, and balance.
//Method to deposit money.
//Method to withdraw money (only if sufficient balance is available).
//Method to display account details.

public class BankAccount {
    private long accountNumber;
    private String holderName;
    private double balance;

    public BankAccount(long accountNumber, String holderName, double balance) {
        this.accountNumber = accountNumber;
        this.holderName = holderName;
        this.balance = balance;
    }

    public void deposit(double amount) {
        balance = balance + amount;
        System.out.println("Deposited " + amount);
    }

    public void withDraw(double amount) {
        if (amount <= balance) {
            balance = balance - amount;
            System.out.println("Withdrawn " + amount);
        } else {
            System.out.println("Insufficient Balance !!!");
        }
    }

    public void displayAccount() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Holder Name: " + holderName);
        System.out.println("Balance: " + balance);
    }

    public static void main(String[] args) {
        BankAccount bankAccount = new BankAccount(10000, "John", 10000);
        bankAccount.displayAccount();
        bankAccount.deposit(1000);
        bankAccount.withDraw(200000);
        bankAccount.displayAccount();
    }

}
