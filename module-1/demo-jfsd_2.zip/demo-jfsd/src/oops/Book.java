package oops;

//2.2) Create a class Book with the following properties and methods:
//Properties: bookId, title, author, price.
//Constructor should allow initializing all values.
//Method to display book details.
//Create another class Library that:
//a. Accepts five books from the user and stores them in an array.
//b. Finds and displays the most expensive book.
//c. Calculates the total cost of all books.
public class Book {
    private long bookId;
    private String title;
    private String author;
    private double price;

    public double getPrice() {
        return price;
    }

    public Book(long bookId, String title, String author, double price) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.price = price;
    }

    public void displayBookDetails() {
        System.out.println("Book Details");
    }

    public String toString() {
        return "Book id = " + bookId + " title = " + title + " author = " + author + " price = " + price;
    }

}

class Library {
    public static void main(String[] args) {
        Book[] books = new Book[5];
        books[0] = new Book(1, "Java", "Oracle", 100);
        books[1] = new Book(2, "JS", "John", 50);
        books[2] = new Book(3, "Python", "Peter", 200);
        books[3] = new Book(4, "HTML", "Zack", 300);
        books[4] = new Book(5, "CSS", "Anand", 500);

        System.out.println(expensiveBook(books));

    }

    public static Book expensiveBook(Book[] books) {
        Book expensiveBook = null;
        double expensivePrice = Double.MIN_VALUE;
        for (int i = 0; i < books.length; i++) {
            if (expensivePrice < books[i].getPrice()) {
                expensivePrice = books[i].getPrice();
                expensiveBook = books[i];
            }
        }

        return expensiveBook;
    }

    // Calculates the total cost of all books.
}
