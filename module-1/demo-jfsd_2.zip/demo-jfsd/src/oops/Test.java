package oops;

public class Test {
    // constructor -> default constructor

    public static void main(String[] args) {

        User user = new User("john", "test@123");

        System.out.println(user.getUserName());

    }
}
