package oops;

public class Child extends Parent {

    public void sub() {
        System.out.println(100 - 200);
    }

    public void calc() {
        add();
    }
}

class Parent {
    public void add() {
        System.out.println(500 + 200);
    }
}

class Parent1 {
    public void sub() {
        System.out.println(500 + 200);
    }
}


