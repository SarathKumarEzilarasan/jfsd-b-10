package com.google;

public class Test {


    public String toString() {
        return "from test class";
    }

    public static void main(String[] args) {


    }
}
