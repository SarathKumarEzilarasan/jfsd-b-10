package com.google;

public class HelloWorld {

    // OOPS -> Object
    public static void main(String[] args) {


    }
}
