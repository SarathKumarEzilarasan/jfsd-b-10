package interfac;

public interface Car {
    void breaks();

    void tyres();
}

class Ford implements Car {

    public void breaks() {

    }

    public void tyres() {

    }
}

class FordSedan extends Ford {

}

class FordSuv extends Ford {

}
