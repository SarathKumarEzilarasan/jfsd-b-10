package collection;

// bounded type
//public class Gen<T extends Number> {
//    public T str;
//
//    public Gen(T str) {
//        this.str = str;
//    }
//
//    public T getStr() {
//        return str;
//    }
//}

public class Gen {
    public <T> void add(T a, T b) {

    }
}
