package java8;

import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class MethodReferenceDemo {
    // static methods , instance methods , constructors

    public static void addition(int a, int b) {
        System.out.println(a + b);
    }

    public void _addition(int a, int b) {
        System.out.println(a + b);
    }

    public MethodReferenceDemo() {
        System.out.println("from constructor");
    }

    public MethodReferenceDemo(String s) {
        System.out.println(s);
    }

    // lambda < method reference

    public static void main(String[] args) {
        unboundMethodReference();
    }

    public static void methodReference() {
        Z z = (a, b) -> System.out.println(a + b);


        Z z1 = MethodReferenceDemo::addition; // static method reference
        z1.add(10, 20);

        MethodReferenceDemo demo = new MethodReferenceDemo();
        Z z2 = demo::_addition; // instance method reference

        X x = (s) -> new MethodReferenceDemo(s);
        X x1 = MethodReferenceDemo::new; // constructor reference
        x1.get("hello");
    }

    public static void boundMethodReference() {
        String name = "john doe";
        Supplier<String> lowerL = () -> name.toUpperCase();
        Supplier<String> lowerMR = name::toUpperCase;
        System.out.println(lowerMR.get());


        Predicate<String> titleL = (title) -> name.contains(title);
        Predicate<String> titleMR = name::contains;
        System.out.println(titleMR.test("john"));
    }

    public static void unboundMethodReference() {
        Function<String, String> upperL = s -> s.toUpperCase();
        Function<String, String> upperMR = String::toUpperCase;
        System.out.println(upperMR.apply("hello"));
    }

    public static void constructorMethodReference() {
        Supplier<StringBuilder> sbL = () -> new StringBuilder();
        Supplier<StringBuilder> sbMR = StringBuilder::new;
    }
}

interface Z {
    void add(int a, int b);
}

interface X {
    //    MethodReferenceDemo get();
    MethodReferenceDemo get(String s);

}

