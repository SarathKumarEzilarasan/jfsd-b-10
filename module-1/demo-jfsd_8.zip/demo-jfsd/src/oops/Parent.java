//package oops;
//
//public class Parent {
//
//    public int i = 100;
//
//    public void add() {
//        System.out.println(100 + 200);
//    }
//
//}
