package multi;

public class SyncDemo {
    // race condition -> data inconsistency problem
    // lock -> object level , class level
    public static void main(String[] args) {
        Display display = new Display();
        Display display1 = new Display();
        Runnable runnable1 = () -> display._print("john");
        Thread t1 = new Thread(runnable1);
        Runnable runnable2 = () -> display._print("peter");
        Thread t2 = new Thread(runnable2);
        t1.start();
        t2.start();
    }
}

class Display {
    public static synchronized void print(String name) {
        for (int i = 0; i < 5; i++) {
            System.out.print("Hello ");
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(name);
        }
        // check balance
    }

    public static void _print(String name) {
        //

        synchronized (Display.class) {
            for (int i = 0; i < 5; i++) {
                System.out.print("Hello ");
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println(name);
            }
        }

        // check balance
    }
}
