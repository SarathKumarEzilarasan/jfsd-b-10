package multi;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Processor {

    private List<Integer> list = new ArrayList<>();
    private final int LIMIT = 5;
    private final int BOTTOM = 0;
    private int value = 0;
    private final Object lock = new Object();
    private static Lock l = new ReentrantLock();

    public void producer() throws InterruptedException {
//        synchronized (lock) {
            while (true) {
                if (list.size() == LIMIT) {
                    System.out.println("Waiting for removing items from the list.....");
                    lock.wait();
                } else {
                    System.out.println("Adding:" + value);
                    list.add(value); // 0
                    value++;  // 1
                    lock.notify();
                }
                Thread.sleep(500);
            }
//        }
    }

    public void consumer() throws InterruptedException {
        synchronized (lock) {
            while (true) {
                if (list.size() == BOTTOM) {
                    System.out.println("Waiting for adding items to the list.....");
                    lock.wait();
                } else {
                    --value;
                    System.out.println("Removing:" + list.remove(value));
                    lock.notify();
                }
                Thread.sleep(500);
            }
        }
    }

    public static void main(String[] args) {
        Processor processor = new Processor();
        Runnable runnable1 = () -> {
            try {
                processor.producer();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        };
        Thread producer = new Thread(runnable1);
        Runnable runnable2 = () -> {
            try {
                processor.consumer();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        };
        Thread consumer = new Thread(runnable2);
        producer.start();
        consumer.start();

    }
}
