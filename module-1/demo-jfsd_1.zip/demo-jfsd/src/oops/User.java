package oops;

public class User {
    public static String userName = "user123";
    static String password = "test@123";

    // getter method
    public String getPassword() {
        return password;
    }

    // setter method
    public void setPassword(String password1) {
        password = password1;
    }

    public static void main(String[] args) {
        System.out.println(password);

    }
}

//class Manager extends User {
//    public static void main(String[] args) {
//        System.out.println(userName);
//        System.out.println(password);
//    }
//}