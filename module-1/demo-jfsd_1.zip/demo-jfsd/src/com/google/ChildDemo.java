package com.google;

import oops.User;

public class ChildDemo{
    public static void main(String[] args) {
        User user = new User();
//        System.out.println(user.password);
    }
}
