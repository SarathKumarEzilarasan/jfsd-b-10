package collection;

import java.util.ArrayList;

public class Test {
    public static void main(String[] args) {
//        Gen gen = new Gen("hello");
//        Gen<String> gen1 = new Gen<>("hello");
//        Gen<Integer> gen2 = new Gen<>(1000);

        Gen gen = new Gen();
        gen.add(100l, 100l);
        gen.add(100.000, 100.1010);
        gen.add(100.000f, 100.1010f);



    }
}

//Number ->