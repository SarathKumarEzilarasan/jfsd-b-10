package file.handling;

import java.io.*;

public class FileOperations {

    private static final String FILE_PATH = "demo.txt";

    public static void main(String[] args) {
        // Create read update delete
        FileOperations fileOperations = new FileOperations();
        fileOperations.createAndWriteToFile("hello world hello world");
        fileOperations.readFromFile();
        fileOperations.updateToFile(" from java");
        fileOperations.readFromFile();
        fileOperations.deleteFile();
    }

    public void createAndWriteToFile(String content) {
        try {
            FileWriter fileWriter = new FileWriter(FILE_PATH);
            BufferedWriter writer = new BufferedWriter(fileWriter);
            writer.write(content);
            writer.close();
        } catch (IOException e) {
            System.out.println("path is invalid");
        }
    }

    public void readFromFile() {
        try {
            FileReader fileReader = new FileReader(FILE_PATH);
            BufferedReader reader = new BufferedReader(fileReader);
            StringBuilder content = new StringBuilder();
            String s = "";
            String line = reader.readLine();
            while (line != null) {
                content.append(line);
                line = reader.readLine();
            }
            reader.close();
            System.out.println(content);
        } catch (IOException e) {
            System.out.println("path is invalid");
        }
    }

    public void updateToFile(String content) {
        try {
            FileWriter fileWriter = new FileWriter(FILE_PATH, true);
            BufferedWriter writer = new BufferedWriter(fileWriter);
            writer.write(content);
            writer.close();
        } catch (IOException e) {
            System.out.println("path is invalid");
        }
    }

    public void deleteFile() {
        File file = new File(FILE_PATH);
        System.out.println(file.delete());
    }
}
