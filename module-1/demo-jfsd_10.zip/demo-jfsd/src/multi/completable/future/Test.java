package multi.completable.future;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class Test {
    public static void main(String[] args) throws ExecutionException, InterruptedException {

    }

    public static void runAsync() throws ExecutionException, InterruptedException {
        CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("from child thread");
        });

        System.out.println(future.get());
    }

    public static void supplyAsync() throws ExecutionException, InterruptedException {
        CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            return "from child thread";
        });

        System.out.println(future.get());
    }

    public static void thenApply() throws ExecutionException, InterruptedException {
        CompletableFuture<String> whatsYourName = CompletableFuture.supplyAsync(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            return "Java";
        }).thenApply(name -> "Hello " + name);

//        CompletableFuture<String> greetingFuture =  whatsYourName.thenApply(name -> "Hello " + name);

        System.out.println(whatsYourName.get());
    }

    public static void thenCombine() throws ExecutionException, InterruptedException {
        CompletableFuture<Double> weightInKgFuture = CompletableFuture.supplyAsync(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            return 70.0;
        });
        CompletableFuture<Double> heightInCmFuture = CompletableFuture.supplyAsync(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            return 173.0;
        });

        CompletableFuture<Double> bmiFuture = weightInKgFuture
                .thenCombine(heightInCmFuture, (weightInKg, heightInCm) -> weightInKg / (heightInCm * heightInCm));


        System.out.println(bmiFuture.get());

    }

    public static void exceptionally() throws ExecutionException, InterruptedException {
        CompletableFuture<Double> weightInKgFuture = CompletableFuture.supplyAsync(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            return 70.0;
        }).exceptionally(ex -> {
            System.out.println(ex.getMessage());
            return 1.0;
        });


        System.out.println(weightInKgFuture.get());

    }
}
