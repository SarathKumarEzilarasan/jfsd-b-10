package multi;

public class Test {
    // New -> Runnable -> Running -> Waiting -> Terminated -----> Thread lifecycle
    public static void main(String[] args) {
        // collections -> non synchronised
        // Vector , Hashtable -> synchronised

        Runnable runnable = () -> {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println("from child");
        };
        Thread t = new Thread(runnable);
        t.setDaemon(true);
        t.start();

        System.out.println("from main");

    }
}
