package regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Demo {
    // Regular Expressions -> regex
    // 2344 2344 2344 2344
    public static void main(String[] args) {
        String text = "sarathezil@gmail.com"; // pattern ->
        String regex = "^\\w{5,}@[a-z]{5,7}.[a-z]{2,3}$";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println("Found : " + matcher.group() + " at position " + matcher.start());
        }
    }

    public static void pattern1() {
        String text = "apple banana"; // pattern ->
        String regex = "a";

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println("Found : " + matcher.group() + " at position " + matcher.start());
        }
    }

    public static void characterClasses() {
        String text = "apple banana"; // pattern ->
        String regex = "[^a-z]"; // [ab], [a-z]

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println("Found : " + matcher.group() + " at position " + matcher.start());
        }
    }

    public static void predefinedCharacterClasses() {
        String text = "apple banana123"; // pattern ->
        String regex = "\\S"; // \d \D \w \W \s \S

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println("Found : " + matcher.group() + " at position " + matcher.start());
        }
    }

    public static void quantifiers() {
        String text = "apple banana123"; // pattern ->
        String regex = "[a-z]{1,}"; // {n} {n,m} {n,} ? * +

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println("Found : " + matcher.group() + " at position " + matcher.start());
        }
    }

    public static void anchors() {
        String text = "apple abanana"; // pattern ->
        String regex = "\\Ba"; // ^ $ \b \B

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println("Found : " + matcher.group() + " at position " + matcher.start());
        }
    }

    public static void groupsAndCapturing() {
        String text = "John Doe,Jane Doe"; // pattern ->
        String regex = "(\\w+) (\\w+)"; // () -> group(1)

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println(matcher.group(0));
            System.out.println(matcher.group(1));
            System.out.println(matcher.group(2));
        }
    }

    public static void alternation() {
        String text = "John Doe,Jane Doe"; // pattern ->
        String regex = "John|Jane"; // |

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println("Found : " + matcher.group() + " at position " + matcher.start());
        }
    }

    public static void lookAhead() {
        String text = "12px 14em 18px 20em"; // pattern ->
        String regex = "\\d+(?!px)";
        // (?=px) -> positive look ahead
        // (?!px) -> negative look ahead

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println("Found : " + matcher.group() + " at position " + matcher.start());
        }
    }

    public static void lookBehind() {
        String text = "$100 %19901"; // pattern ->
        String regex = "(?<!\\$)\\d+";
        // (?<=\$) -> positive look behind
        // (?<!\$) -> negative look behind

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            System.out.println("Found : " + matcher.group() + " at position " + matcher.start());
        }
    }
}
