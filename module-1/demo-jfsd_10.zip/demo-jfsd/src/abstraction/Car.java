package abstraction;

public abstract class Car {
    public abstract void breaks();

    public void tyres(){

    }
}

class Bmw extends Car {
    public void breaks() {
        System.out.println("advanced breaking system");
    }
}

class Tata extends Car {
    public void breaks() {
        System.out.println("tata breaking system");
    }
}

abstract class Ford extends Car {

}

class FordSedan extends Ford {
    public void breaks() {

    }
}

class FordSuv extends Ford {
    public void breaks() {

    }
}
