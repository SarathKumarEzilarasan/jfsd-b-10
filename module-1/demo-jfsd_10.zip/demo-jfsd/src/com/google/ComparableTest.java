package com.google;

import java.util.*;

public class ComparableTest {
    public static void main(String[] args) {
        Student s1 = new Student("john", 18, 9);
        Student s2 = new Student("peter", 20, 8);
        Student s3 = new Student("zack", 10, 7);
//
//
////        System.out.println(s1.compareTo(s2));
//        AgeComparator ageComparator = new AgeComparator();
//        System.out.println(ageComparator.compare(s1, s2));
//
//
//
//        GradeComparator gradeComparator = new GradeComparator();
//        System.out.println(gradeComparator.compare(s1, s2));

        List<Student> list = Arrays.asList(s1, s2, s3);
        System.out.println(list);
        list.sort(new GradeComparator());
        System.out.println(list);

        // TreeSet -> ????
    }
}

// comparable -> compareTo -> multi values we cannot compare bc only 1 method -> comparator
class AgeComparator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        return o1.getAge() - o2.getAge();
    }
}

class GradeComparator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        return o1.getGrade() - o2.getGrade();
    }
}
