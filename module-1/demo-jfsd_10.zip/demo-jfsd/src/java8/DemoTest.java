package java8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;


public class DemoTest {
    private static final String FILE_PATH = "demo.txt";

    public static void main(String[] args) {


    }

    public static void readFromFile() throws IOException {
        FileReader fileReader = null;
        StringBuilder content = null;
        fileReader = new FileReader(FILE_PATH);
        try (BufferedReader reader = new BufferedReader(fileReader)) {
            content = new StringBuilder();
            String s = "";
            String line = reader.readLine();
            while (line != null) {
                content.append(line);
                line = reader.readLine();
            }
            System.out.println(content);
        } catch (IOException e) {
            System.out.println("path is invalid");
        }
    }

    public static void tryWithResource() {
        AutoCloseable closeable = () -> System.out.println("from close method");
        try (closeable) {
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void dropWhile() {
        List<Integer> list = Arrays.asList(10, 2, 30, 3, 40);

        System.out.println(list.stream().takeWhile(x -> x % 5 == 0).toList());
        System.out.println(list.stream().dropWhile(x -> x % 5 == 0).toList());
    }

    public static void varKeyword() {
        var i = 100;
        int j;
        j = 100;

        var map = new HashMap<Integer, String>();
//        var s = null;
    }

    public static void contentBlock() {
        //content block
        String s = "hello " +
                "world";

        String st = """
                   hello 
                   world from java
                """;

        System.out.println(st);
    }

    public static void switchWithLambda() {
        int i = 11;

        String s = switch (i) {
            case 1 -> "choice 1";
            default -> "invalid";
        };

        System.out.println(s);
    }

    public static void recordExample() {
        //        Employee employee1 = new Employee("john", "20");
//        Employee employee2 = new Employee("john", "20");
//        employee1.getAge();
//        employee1.setAge("30");
//
//        System.out.println(employee1 == employee2);
//        System.out.println(employee1);

        _Employee employee1 = new _Employee("john", "20");
        _Employee employee2 = new _Employee("john", "20");

        System.out.println(employee1.hashCode());
        System.out.println(employee2.hashCode());
        System.out.println(employee1.name());

        System.out.println(employee1.equals(employee2));

        System.out.println(employee1);
    }
}

interface M {
    private void add() {

    }

    private static void sub() {

    }
}

class Employee {
    private String name;
    private String age;

    public Employee(String name, String age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", age='" + age + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Employee employee = (Employee) o;
        return name.equals(employee.name) && age.equals(employee.age);
    }

    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + age.hashCode();
        return result;
    }
}
