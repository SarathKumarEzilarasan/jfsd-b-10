package java8;

public record _Employee(String name, String age) {

}


//sealed class Parent permits Child1 {
//
//}
//
//sealed class Child1 extends Parent permits Child2 {
//
//}
//
//class Child2 extends Parent {
//
//}

// final , non-sealed , sealed
