package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class TerminalOperations {
    public static void main(String[] args) {
        doMinAndMax();
    }

    public static void doMinAndMax() {
        List<String> list = Arrays.asList();
        Optional<String> min = list.stream().min((o1, o2) -> o1.length() - o2.length());
//        Stream.of("apple", "orange", "ban").min((o1, o2) -> o1.length() - o2.length());
//        System.out.println(min);
        min.ifPresent(i -> System.out.println(i));
    }

    public static void doCount() {
        List<String> list = Arrays.asList("apple", "orange", "ban");
        long count = list.stream().count();
        System.out.println(count);
    }

    public static void doFindAnyAndFindFirst() {
        List<String> list = Arrays.asList("apple", "orange", "ban");
        Optional<String> any = list.stream().findAny();
        System.out.println(any.get());
        Optional<String> first = list.stream().findFirst();
        System.out.println(first.get());
    }

    public static void doMatches() {
        List<String> list = Arrays.asList("apple", "orange", "ban");
//        Predicate<String> predicate = new Predicate<String>() {
//            @Override
//            public boolean test(String name) {
//                return name.startsWith("a");
//            }
//        };
        Predicate<String> predicate = name -> name.startsWith("a");

        System.out.println(list.stream().anyMatch(predicate));
        System.out.println(list.stream().allMatch(predicate));
        System.out.println(list.stream().noneMatch(predicate));
    }

    public static void doForEach() {
        List<String> list = Arrays.asList("apple", "orange", "ban");
        list.stream().forEach(name -> System.out.println(name));
    }

    public static void doReduce1() {
        List<String> list = Arrays.asList("apple", "orange", "ban");
//        list.stream().reduce("", new BinaryOperator<String>() {
//            @Override
//            public String apply(String s1, String s2) {
//                return s1 + s2;
//            }
//        });
        String name = list.stream()
//                .filter(s -> s.length() > 10)
                .reduce("", (s1, s2) -> s1 + s2);
        System.out.println(name);
    }

    public static void doReduce2() {
        List<String> list = Arrays.asList("apple", "orange", "ban", "pineapple");
        String name = list.stream()
//                .filter(s -> s.length() > 10)
                .reduce("",
                        (s1, s2) -> s1 + s2,
                        (c1, c2) -> c1 + c2
                );
        System.out.println(name);
    }

    public static void doCollect() {
        List<String> list = Arrays.asList("apple", "orange", "ban", "pineapple");

        StringBuilder word = list.stream()
                .collect(
                        () -> new StringBuilder(),
                        (sb, s) -> sb.append(s),
                        (sb1, sb2) -> sb1.append(sb2)
                );

        System.out.println(word);
    }
}
