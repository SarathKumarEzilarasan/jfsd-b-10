package oops;


public class Demo {

    public static void add(int a, int b) {
        System.out.println(a + b);
    }

    public static void add(float a, int b) {
        System.out.println(a + b);
    }

    public static void main(String[] args) {
        add(100, 200);
//        add(100, 200, 300);
    }
}

// function name + no. of parameters should be unique + type of arguments
