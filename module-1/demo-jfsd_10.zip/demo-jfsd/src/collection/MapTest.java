package collection;

import java.util.*;

public class MapTest {
//    public static void main(String[] args) {
//        // Map -> [key,value] HashMap, LinkedHashMap, TreeMap
//
//        Map<String, Integer> map = new HashMap<>();
//        map.put("john", 1);
//        map.put("john", 10);
//        map.put("peter", 1);
//        map.put("zack", 1);
//        System.out.println(map.get("peter"));
//        map.containsKey("john");
//        map.containsValue(89999991);
//
//        map.put("zack", 999000009);
//
//        Set<String> keys = map.keySet();
//
////        for (String key:keys){
////            System.out.println(key);
////        }
//
//        Collection<Integer> values = map.values();
//
////        for (Integer value:values){
////            System.out.println(value);
////        }
//
//        Set<Map.Entry<String, Integer>> entries = map.entrySet();
//
////        for (Map.Entry<String, Integer> entry : entries) {
////            System.out.println(entry.getKey());
////            System.out.println(entry.getValue());
////        }
//
//        countFrequency("wwwqqxxxa1212232323232323");
//
//    }


    public static void main(String[] args) {
        // given a map -> sort it based on values

//        Map<String, Integer> map = new TreeMap<>(Collections.reverseOrder());
        Map<String, Integer> map = new HashMap<>();
        map.put("apple", 20);
        map.put("date", 30);
        map.put("banana", 10);
        map.put("orange", 2);

        Set<Map.Entry<String, Integer>> entries = map.entrySet();
        List<Map.Entry<String, Integer>> entryList = new ArrayList<>(entries);
        entryList.sort((o1, o2) -> o1.getValue().compareTo(o2.getValue())); // 2,10,20,30
        System.out.println(entryList);
    }

    public static void countFrequency(String input) {
        Map<Character, Integer> map = new LinkedHashMap<>();
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i); // w,2
            if (map.containsKey(ch)) {
                int oldValue = map.get(ch);
                map.put(ch, oldValue + 1);
            } else {
                map.put(ch, 1);
            }
        }
        Set<Map.Entry<Character, Integer>> entries = map.entrySet();
        for (Map.Entry<Character, Integer> entry : entries) {
            System.out.print(entry.getKey());
            System.out.print(entry.getValue());
        }
    }
}

// array [data structure] -> collections [list,set,map]
